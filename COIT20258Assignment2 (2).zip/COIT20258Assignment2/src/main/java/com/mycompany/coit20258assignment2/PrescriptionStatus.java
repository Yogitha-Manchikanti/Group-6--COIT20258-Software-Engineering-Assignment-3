package com.mycompany.coit20258assignment2;

public enum PrescriptionStatus {
    NEW, APPROVED, REFILLED, REJECTED
}
