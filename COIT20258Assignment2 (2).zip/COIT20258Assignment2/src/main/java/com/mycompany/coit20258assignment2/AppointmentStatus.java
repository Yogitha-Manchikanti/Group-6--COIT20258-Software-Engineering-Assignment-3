package com.mycompany.coit20258assignment2;

import java.io.Serializable;

public enum AppointmentStatus implements Serializable {
    BOOKED,
    RESCHEDULED,
    CANCELED
}
